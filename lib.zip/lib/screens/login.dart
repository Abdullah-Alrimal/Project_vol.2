import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:project_test/bloc/login_bloc.dart';
import 'package:project_test/bloc/user.dart';
import 'package:project_test/bloc/user_event.dart';
import 'package:http/http.dart' as http;

import 'otp.dart';
class Login extends StatefulWidget {

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String _email;

  insertUser() async{
    //I tried and used the sent url but it would not work because i can't change (https://f724cd1d-6331-44ea-9eb0-e1c54826bfa.mock.pstmn.io) to http since https does not work so instead i used localhost.
    var res = await http.post(Uri.parse("https://30a36a5b-aaf7-434a-a060-5b68e41cf0d8.mock.pstmn.io/login"),
    body: {
      "email":_email
    }
    );
    print(res.body);
    return res;
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: new AppBar(
        title: new Text("My Application"),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top:200 ),
        child: Column(
            children: [
        Padding(
        padding: EdgeInsets.all(10),
        child: TextField(
          onChanged: (text) {
            setState((){
              _email = text;
            });
          },
          keyboardType: TextInputType.text,
          decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Email",
              hintText: 'Enter valid Email'

          ),

        ),
      ),
      Container(
      width: 150,
      child: FlatButton(onPressed: (){
        insertUser();
        Navigator.of(context).pushNamed(Otp.routeName, arguments: _email);
      },
        child: Text(
          'Login',
          style: TextStyle(color: Colors.white, fontSize: 15),
        ),
        color: Theme.of(context).accentColor,

        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

      ),
    ),

    ],
    ),
    ),
    );
  }
}
