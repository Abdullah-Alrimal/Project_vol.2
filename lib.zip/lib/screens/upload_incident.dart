import 'dart:convert';
import 'dart:html';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class UploadIncident extends StatefulWidget {

  @override
  _UploadIncidentState createState() => _UploadIncidentState();
}

class _UploadIncidentState extends State<UploadIncident> {
  var jsonRes;
  XFile _image;

  Future pickImage() async{

    var image = await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      _image = image;
    });
  }

  uploadIncident() async{
    var res = await http.post(Uri.parse("https://30a36a5b-aaf7-434a-a060-5b68e41cf0d8.mock.pstmn.io/incident/upload/e172100d-60d0-4dd"),
    body:{
      "image": _image
    }
    );
    jsonRes = json.decode(res.body);
    return jsonRes;
  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        appBar: new AppBar(
          title: new Text("My Application"),
        ),
        body: FlatButton(
              onPressed: (){
                pickImage().then((value){
                  uploadIncident();
                }
                );
              },
          child: Text("Upload your incident"),
        )
    );

  }
}
