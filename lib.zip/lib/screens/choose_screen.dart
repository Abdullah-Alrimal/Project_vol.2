
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:project_test/screens/incidents_type.dart';

import 'incidents.dart';

class ChooseScreen extends StatefulWidget {
  static const routeName = 'choose-screen';

  @override
  _ChooseScreenState createState() => _ChooseScreenState();
}

class _ChooseScreenState extends State<ChooseScreen> {
  File _image;

  Future pickImage() async{

    var image = await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      _image = File(image.path);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: new AppBar(
          title: new Text("My Application"),
        ),
        body: Column(
          children: [
            Row(
              children: [
                Expanded(child: RaisedButton(onPressed: (){Navigator.of(context).pushNamed(Incidents.routeName);}, child: Text("Incidents"),)),
                Expanded(child: RaisedButton(onPressed: (){Navigator.of(context).pushNamed(IncidentsType.routeName);}, child: Text("Incident's type"),)),
              ],
            ),
            FlatButton(onPressed: (){
                pickImage();
            }, child: Text("Upload Incident")),

            Container(
              child: _image != null ? Image.file(_image) : null,
            )
          ],
        )
    );
  }
}
