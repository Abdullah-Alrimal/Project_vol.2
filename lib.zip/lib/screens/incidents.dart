import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Incidents extends StatelessWidget {
  static const routeName = 'incident-screen';
  var jsonRes;


  insertUser() async{
    var res = await http.get(Uri.parse("https://30a36a5b-aaf7-434a-a060-5b68e41cf0d8.mock.pstmn.io/incident"),);
    if(res.statusCode == 200){
      jsonRes = json.decode(res.body);
      return jsonRes["incidents"];
    }
  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        appBar: new AppBar(
          title: new Text("My Application"),
        ),
        body:FutureBuilder(
          future: insertUser(),
          builder: (context, snapshot) {
            if(snapshot.data != null){
              return ListView.builder(
                  itemCount: snapshot.data.length,
                  itemBuilder: (context, index){
                    print(snapshot.data[0]);
                    return Card(
                      elevation: 4,
                      child: ListTile(
                        title: Text(snapshot.data[index]["description"]) ,
                      ),
                    );

                  }
              );
            }else{
              return Center(child: CircularProgressIndicator());
            }
          },
        )
    );

  }
}
