
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:project_test/bloc/incident.dart';
import 'package:project_test/screens/choose_screen.dart';

import 'incidents.dart';


class Otp extends StatefulWidget {

  static const routeName = 'otp-screen';

  @override
  _OtpState createState() => _OtpState();
}

class _OtpState extends State<Otp> {
  final TextEditingController otpController = new TextEditingController();
  String _otp;
  String email;
  var response;
  getOtp() async{
    var res = await http.post(Uri.parse("https://30a36a5b-aaf7-434a-a060-5b68e41cf0d8.mock.pstmn.io/verify-otp"),
        body: {
      "email": email,
      "otp": _otp,
    });
    response = json.decode(res.body);
    return res;
  }

  @override
  Widget build(BuildContext context) {
    email = ModalRoute.of(context).settings.arguments;
    return Scaffold(
        appBar: new AppBar(
          title: new Text("Multi Page Application"),
        ),
        body:
      Padding(
      padding: const EdgeInsets.only(top:200 ),
      child: Column(
        children: [
          TextField(
            onChanged: (text) {
              setState((){
                _otp = text;
              });
            },
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Otp",
                hintText: 'Enter Otp'

            ),

          ),
          Container(
            width: 150,
            child: FlatButton(onPressed: (){
              getOtp();
              Navigator.of(context).pushNamed(ChooseScreen.routeName);
            },
              child: Text(
                'Submit',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              color: Theme.of(context).accentColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

            ),
          ),
        ],
      ),
    ),);
  }
}
