import 'package:flutter/cupertino.dart';
import '../bloc/user.dart';

enum EventType {add}


class UserEvent {
  User user;
  EventType userEvent;

  //this is a constructor
  UserEvent.add(User user){
    this.userEvent = EventType.add;
    this.user = user;
  }


}