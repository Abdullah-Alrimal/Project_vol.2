import 'package:bloc/bloc.dart';
import 'package:project_test/bloc/incidents_event.dart';
import '../bloc/user.dart';
import '../bloc/user_event.dart';
import 'incident.dart';
import 'incidents_event.dart';
import 'package:http/http.dart' as http;


class IncidentBloc extends Bloc<IncidentEvent, List<Incident>> {

  IncidentBloc() : super([]);


  @override
  List<Incident> get initailState => List<Incident>();

  @override
  Stream<List<Incident>> mapEventToState(IncidentEvent event) async*{
    switch (event.incidentEvent){
      case EventIncidentType.upload :
      //creat a copy from the state

        List<Incident> newState = List.from(state);
        if(event.incident != null){
          newState.add(event.incident);
        }
        yield newState;
    }
  }

}