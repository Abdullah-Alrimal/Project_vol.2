import 'package:flutter/cupertino.dart';
import '../bloc/user.dart';
import 'incident.dart';

enum EventIncidentType {upload}


class IncidentEvent {
  Incident incident;
  EventIncidentType incidentEvent;

  //this is a constructor
  IncidentEvent.add(Incident incident){
    this.incidentEvent = EventIncidentType.upload;
    this.incident = incident;
  }


}