
import 'package:flutter/material.dart';


class Incident{
 String description ;
 String typeId ;
  double latitude;
 double longitude ;

 Incident(description, typeId, latitude, longitude){
    this.description=description;
    this.typeId = typeId;
    this.latitude = latitude;
    this.longitude = longitude;
  }




}