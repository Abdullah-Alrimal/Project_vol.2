
import 'package:flutter/material.dart';


class User{
   String email;
   String otp;
   User(email, {otp}){
     this.email= email;
     this.otp = otp;
   }




}