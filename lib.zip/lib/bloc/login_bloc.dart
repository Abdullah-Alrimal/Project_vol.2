import 'package:bloc/bloc.dart';
import '../bloc/user.dart';
import '../bloc/user_event.dart';

class LoginBloc extends Bloc<UserEvent, List<User>> {

  LoginBloc() : super([]);


  @override
  List<User> get initailState => List<User>();

  @override
  Stream<List<User>> mapEventToState(UserEvent event) async*{
    switch (event.userEvent){
      case EventType.add:
        //creat a copy from the state
        List<User> newState = List.from(state);
        if(event.user != null){
          newState.add(event.user);
        }
        yield newState;
    }
  }

}