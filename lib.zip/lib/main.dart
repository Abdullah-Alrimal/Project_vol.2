import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:project_test/bloc/incident.dart';
import 'package:project_test/screens/incidents_type.dart';
import './screens/choose_screen.dart';
import './screens/incidents.dart';
import './screens/login.dart';
import 'bloc/login_bloc.dart';
import 'screens/otp.dart';
void main() {
  // BlocSupervisor.delegate for the debugging page to work
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => LoginBloc(),
      child: MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          // This is the theme of your application.
          //
          // Try running your application with "flutter run". You'll see the
          // application has a blue toolbar. Then, without quitting the app, try
          // changing the primarySwatch below to Colors.green and then invoke
          // "hot reload" (press "r" in the console where you ran "flutter run",
          // or simply save your changes to "hot reload" in a Flutter IDE).
          // Notice that the counter didn't reset back to zero; the application
          // is not restarted.
          primaryColor: Colors.deepPurple,
          accentColor: Colors.blueAccent,

        ),
        home: Login(),
        routes: {
          Otp.routeName: (ctx) => Otp(),
          Incidents.routeName: (ctx) => Incidents(),
          ChooseScreen.routeName: (ctx) => ChooseScreen(),
          IncidentsType.routeName: (ctx) => IncidentsType()
      },

      ),
    );
  }
}



